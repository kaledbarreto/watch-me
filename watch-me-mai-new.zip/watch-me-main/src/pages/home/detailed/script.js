document.addEventListener("DOMContentLoaded", function() {
    var mySpan = document.getElementById("show-more");
    mySpan.addEventListener("click", function() {
      window.location.href="http://127.0.0.1:5500/src/pages/home/";
    });
  });