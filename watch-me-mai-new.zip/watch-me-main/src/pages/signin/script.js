// document.addEventListener("DOMContentLoaded", function () {
//   document
//     .getElementById("signup-form")
//     .addEventListener("submit", function (event) {
//       window.location.href = "http://127.0.0.1:5500/src/pages/home/";
//     });
// });

document.addEventListener("DOMContentLoaded", function () {
  var mySpan = document.getElementById("signup");
  var entrarBtn = document.getElementById("entrar");

  mySpan.addEventListener("click", function () {
    window.location.href = "http://127.0.0.1:5500/src/pages/signup/";
  });

  entrarBtn.addEventListener("click", function () {
    window.location.href = "http://127.0.0.1:5500/src/pages/home/";
  });
});
